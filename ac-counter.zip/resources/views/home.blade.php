@extends('layouts.master')

@section('content')
<div class="container">
<router-view></router-view>
</div>
@endsection
