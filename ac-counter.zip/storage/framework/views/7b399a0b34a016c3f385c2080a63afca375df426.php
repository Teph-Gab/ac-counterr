<?php $__env->startSection('content'); ?>
<div class="container">
<router-view></router-view>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Teph_Gab\Documents\Web-Project\ac-counter\resources\views/home.blade.php ENDPATH**/ ?>